const express = require('express');
const app = express();

app.use(express.json());

var students = [
{
	name : "Palash Debsharma",
	course : "MS",
	dept : "Computer Science",
	roll : 1
},
{
	name : "Palash Debsharma",
	course : "MS",
	dept : "Computer Science",
	roll : 2
},
{
	name : "Palash Debsharma",
	course : "MS",
	dept : "Computer Science",
	roll : 3
},
{
	name : "Palash Debsharma",
	course : "MS",
	dept : "Computer Science",
	roll : 4
},
{
	name : "Palash Debsharma",
	course : "MS",
	dept : "Computer Science",
	roll : 5
}
]
app.get('/',(req,res)=> res.send('This is home page'));
app.get('/students',(req,res)=> res.send(students));
app.get('/students/:id',(req, res)=> {
	const student = students.find(s => s.roll === parseInt(req.params.id));

	if(!student) res.status(404).send('Student not found');
	res.status(200).send(student);
});

app.post('/students',(req, res)=> {

	let student = {
		name : req.body.name,
		course : req.body.course,
		dept : req.body.dept,
		roll : students.length + 1
	}

	students.push(student);
	res.status(201).send(student);

});

app.put('/students/:id',(req, res) => {
	let student = students.find(s => s.roll === parseInt(req.params.id));

	if(!student) res.status(404).send('Student not found');

	student = {name : req.body.name,
			   course : req.body.course,
				dept : req.body.dept,
				roll : req.params.id};

	res.status(200).send(student);
});

app.delete('/students/:id',(req, res)=>{
	const student = students.find(s => s.roll === parseInt(req.params.id));
	if(!student) res.status(404).send('Student not found');

	const index = students.indexOf(student);
	students.splice(index,1);
	res.status(200).send(students);
});


app.listen(3000,console.log('Express Server is listening @ port 3000'));