var student = [
{
	"name" : "Palash Debsharma 1",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 1,
},
{
	"name" : "Palash Debsharma 2",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 2,
},
{
	"name" : "Palash Debsharma 3",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 3,
},
{
	"name" : "Palash Debsharma 4",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 4,
},
{
	"name" : "Palash Debsharma 5",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 5,
},
{
	"name" : "Palash Debsharma 6",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 6,
},
{
	"name" : "Palash Debsharma 7",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 7,
},
{
	"name" : "Palash Debsharma 8",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 8,
},
{
	"name" : "Palash Debsharma 9",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 9,
},
{
	"name" : "Palash Debsharma 10",
	"Course" : "MS",
	"Dept" : "Computer Science",
	"Roll No" : 10,
},
]