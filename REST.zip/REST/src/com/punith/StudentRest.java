package com.punith;

import javax.websocket.server.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;


public class StudentRest {

	// http://localhost:8080/REST/rest/pUNITH
		@GET
		@Path("/{name}")
		public Response sayHello(@PathParam("name") String msg) {
			String output = "Hello, " + msg + "!";
			return Response.status(200).entity(output).build();
		}
		}
