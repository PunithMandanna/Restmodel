package com.punith;
import org.glassfish.jersey.server.ResourceConfig;
public class RestServer extends ResourceConfig{
	
	

	

		public RestServer() {
			// Define the package which contains the service classes
			packages("com.fasterxml.jackson.jaxrs.json");
			packages("com.punith.StudentRest");
		}
	}



